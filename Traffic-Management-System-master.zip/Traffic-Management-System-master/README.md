# Traffic-Management-System
Smart Traffic Management System which changes window time of green light based on density of vehicles.
